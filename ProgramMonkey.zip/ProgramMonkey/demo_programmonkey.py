import programmonkey_cnn as programmonkey
import tensorflow as tf

programmonkey.main('DATA/train_images_names.txt', 'DATA/validation_images_names.txt')
